from pathlib import Path


def is_correct(path):
    return Path(path).exists() and "CORRECT" in Path(path).read_text(encoding="utf-8")


def main():
    score = sum(is_correct(f"quiz{i}_result.txt") for i in [1, 2, 3])
    status = "Summary Completed" if score == 3 else "Summary Incomplete"

    text = f"""=================================================
KHUYEN NGHI CAU HINH FHSS CHO 3 DU AN
=================================================
QUAN SU: hop=5, m=2 (uu tien BER thap)
VOIP:    hop=1, m=8 (uu tien capacity)
RADIO:   hop=3, m=4 (can bang PSNR/BER/capacity)
QUIZ SCORE: {score}/3
{status}
"""
    Path("final_recommendation.txt").write_text(text, encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
