from pathlib import Path

from fhss_core import evaluate, generate_cover, generate_stego, save_json, save_spectrogram_png, write_wav


HOPS = [1, 3, 5]
M_VALUES = [2, 4, 8]


def main():
    Path("results").mkdir(exist_ok=True)
    write_wav("original.wav", generate_cover())

    results = []
    idx = 1

    for hop in HOPS:
        for m in M_VALUES:
            wav_name = f"stego_hop{hop}_m{m}.wav"
            png_name = f"spec_hop{hop}_m{m}.png"

            if not Path(wav_name).exists():
                write_wav(wav_name, generate_stego(hop, m))

            save_spectrogram_png(wav_name, png_name)
            result = evaluate(hop, m)
            results.append(result)

            print(
                f"[{idx}/9] hop={hop}, m={m}: "
                f"PSNR={result['psnr']:.2f}dB, BER={result['ber']:.2f}%, "
                f"Cap={result['capacity']:.2f} bit/s"
            )
            idx += 1

    Path("quansu.wav").write_bytes(Path("stego_hop5_m2.wav").read_bytes())
    Path("voip.wav").write_bytes(Path("stego_hop1_m8.wav").read_bytes())
    Path("radio.wav").write_bytes(Path("stego_hop3_m4.wav").read_bytes())

    data = {
        "configurations": 9,
        "results": results,
        "scenarios": {
            "quansu": {"hop": 5, "m": 2, "reason": "BER thap khi nhieu manh"},
            "voip": {"hop": 1, "m": 8, "reason": "capacity cao"},
            "radio": {"hop": 3, "m": 4, "reason": "can bang PSNR/BER/capacity"},
        },
    }

    save_json("data.json", data)
    Path("grid_done.txt").write_text("GRID DONE\n9 configurations\n", encoding="utf-8")
    print("[+] Da sinh 9 wav + 9 spectrogram + data.json")


if __name__ == "__main__":
    main()
