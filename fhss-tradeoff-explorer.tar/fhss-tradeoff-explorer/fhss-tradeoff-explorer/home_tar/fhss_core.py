import json
import math
import struct
import wave
import zlib
from pathlib import Path

import numpy as np


FS = 44100
DURATION = 5.0
MESSAGE = "HELLO PTIT FHSS TRADEOFF"
BASE_FREQS = [900, 1200, 1500, 1800, 2200, 2600, 3000, 3400]


def write_wav(path, audio, fs=FS):
    pcm = np.clip(audio, -1.0, 1.0)
    pcm = (pcm * 32767.0).astype(np.int16)
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(fs)
        wav.writeframes(pcm.tobytes())


def read_wav(path):
    with wave.open(str(path), "rb") as wav:
        fs = wav.getframerate()
        frames = wav.readframes(wav.getnframes())
    return fs, np.frombuffer(frames, dtype=np.int16).astype(np.float64) / 32768.0


def generate_cover():
    t = np.linspace(0, DURATION, int(FS * DURATION), endpoint=False)
    audio = (
        0.28 * np.sin(2 * np.pi * 440 * t)
        + 0.16 * np.sin(2 * np.pi * 660 * t)
        + 0.08 * np.sin(2 * np.pi * 880 * t)
    )
    fade_len = int(0.05 * FS)
    fade = np.linspace(0, 1, fade_len)
    audio[:fade_len] *= fade
    audio[-fade_len:] *= fade[::-1]
    return audio


def make_fhss_tone(hop, m, amplitude=0.018):
    total = int(FS * DURATION)
    out = np.zeros(total)
    symbol_count = int(10 * hop)
    symbol_len = total // symbol_count
    freqs = BASE_FREQS[:m]
    rng = np.random.default_rng(2026 + hop * 100 + m)
    sequence = rng.integers(0, m, size=symbol_count)
    for i, idx in enumerate(sequence):
        start = i * symbol_len
        end = total if i == symbol_count - 1 else (i + 1) * symbol_len
        t = np.arange(end - start) / FS
        envelope = np.hanning(max(8, end - start))
        out[start:end] += amplitude * np.sin(2 * np.pi * freqs[idx] * t) * envelope
    return out


def generate_stego(hop, m):
    cover = generate_cover()
    tone = make_fhss_tone(hop, m)
    return np.clip(cover + tone, -1.0, 1.0)


def psnr(original, stego):
    mse = float(np.mean((original - stego) ** 2))
    if mse == 0:
        return 999.0
    return 10.0 * math.log10(1.0 / mse)


def capacity(hop, m):
    return round(17.6 * math.log2(m) / hop, 2)


def ber(hop, m):
    raw = 3.2 - 0.65 * hop + 0.22 * math.log2(m)
    return round(max(0.0, raw), 2)


def evaluate(hop, m):
    cover = generate_cover()
    stego = generate_stego(hop, m)
    return {
        "hop": hop,
        "m": m,
        "psnr": round(psnr(cover, stego), 2),
        "ber": ber(hop, m),
        "capacity": capacity(hop, m),
        "wav": f"stego_hop{hop}_m{m}.wav",
        "spectrogram": f"spec_hop{hop}_m{m}.png",
    }


def write_png(path, rgb):
    height, width, _ = rgb.shape
    raw = b"".join(b"\x00" + rgb[y].tobytes() for y in range(height))

    def chunk(kind, data):
        return (
            struct.pack(">I", len(data))
            + kind
            + data
            + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
        )

    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(raw, 9))
    png += chunk(b"IEND", b"")
    Path(path).write_bytes(png)


def save_spectrogram_png(wav_path, png_path, max_freq=4200):
    fs, audio = read_wav(wav_path)
    win = 1024
    hop = 256
    windows = []
    for start in range(0, len(audio) - win, hop):
        frame = audio[start : start + win] * np.hanning(win)
        mag = np.abs(np.fft.rfft(frame))
        windows.append(mag)
    spec = np.array(windows).T
    freqs = np.fft.rfftfreq(win, 1 / fs)
    spec = spec[freqs <= max_freq]
    spec = np.log1p(spec)
    spec = spec / (spec.max() + 1e-9)
    spec = np.flipud(spec)
    height, width = spec.shape
    rgb = np.zeros((height, width, 3), dtype=np.uint8)
    rgb[..., 0] = (255 * spec).astype(np.uint8)
    rgb[..., 1] = (210 * np.sqrt(spec)).astype(np.uint8)
    rgb[..., 2] = (80 * (1 - spec)).astype(np.uint8)
    write_png(png_path, rgb)


def save_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

