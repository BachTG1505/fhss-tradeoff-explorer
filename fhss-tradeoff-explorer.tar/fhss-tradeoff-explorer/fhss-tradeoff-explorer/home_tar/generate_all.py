from generate_grid import main


if __name__ == "__main__":
    main()
