from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse


ANSWERS = {
    "1": ("B", "Q1 - Hop Rate Visual: CORRECT\nSelected: B (hop=5, m=2)\n"),
    "2": ("C", "Q2 - MFSK Capacity: CORRECT\nSelected: C (Capacity)\n"),
    "3": ("C", "Q3 - VoIP Scenario: CORRECT\nSelected: C (hop=1, m=8)\n"),
}


class QuizHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path != "/quiz":
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not found")
            return

        params = parse_qs(parsed.query)
        q = params.get("q", [""])[0]
        a = params.get("a", [""])[0].upper()
        correct, text = ANSWERS.get(q, ("", ""))
        ok = a == correct
        out = text if ok else f"Q{q}: WRONG\nSelected: {a}\n"
        with open(f"quiz{q}_result.txt", "w", encoding="utf-8") as f:
            f.write(out)

        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(("CORRECT" if ok else "WRONG").encode("utf-8"))

    def log_message(self, fmt, *args):
        return


def main():
    print("Quiz server running on http://localhost:8000")
    HTTPServer(("0.0.0.0", 8000), QuizHandler).serve_forever()


if __name__ == "__main__":
    main()

