from pathlib import Path

from fhss_core import MESSAGE, generate_cover, write_wav


def main():
    write_wav("original.wav", generate_cover())
    Path("message.txt").write_text(MESSAGE + "\n", encoding="utf-8")
    print("START LAB DONE")
    print("original.wav and message.txt created")


if __name__ == "__main__":
    main()

