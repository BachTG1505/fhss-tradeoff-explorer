import numpy as np


def haar_dwt_level1(samples):
    usable = samples[: len(samples) - len(samples) % 2]
    even = usable[0::2]
    odd = usable[1::2]
    approx = (even + odd) / np.sqrt(2.0)
    detail = (even - odd) / np.sqrt(2.0)
    return approx, detail


def haar_energy(samples, levels=5):
    current = samples
    energies = []
    for _ in range(levels):
        current, detail = haar_dwt_level1(current)
        energies.append(float(np.sum(detail * detail)))
    energies.append(float(np.sum(current * current)))
    return energies

