import json
from pathlib import Path


def row_for_result(r):
    return (
        f"<tr><td>hop={r['hop']}, m={r['m']}</td>"
        f"<td>{r['psnr']:.2f} dB</td>"
        f"<td>{r['ber']:.2f}%</td>"
        f"<td>{r['capacity']:.2f} bit/s</td>"
        f"<td><img src='{r['spectrogram']}'></td></tr>"
    )


def main():
    data = json.loads(Path("data.json").read_text(encoding="utf-8"))
    template = Path("report_template.html").read_text(encoding="utf-8")
    rows = "\n".join(row_for_result(r) for r in data["results"])
    html = template.replace("{{ROWS}}", rows)
    Path("report.html").write_text(html, encoding="utf-8")
    Path("report_built.txt").write_text("REPORT BUILT\n", encoding="utf-8")
    print("REPORT BUILT")
    print("Open with: firefox report.html &")


if __name__ == "__main__":
    main()

