import argparse
from pathlib import Path

from fhss_core import evaluate, generate_cover, generate_stego, save_spectrogram_png, write_wav


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--hop", type=int, required=True, choices=[1, 3, 5])
    parser.add_argument("--m", type=int, required=True, choices=[2, 4, 8])
    parser.add_argument("--export-spec", action="store_true")
    args = parser.parse_args()

    if not Path("original.wav").exists():
        write_wav("original.wav", generate_cover())

    wav_name = f"stego_hop{args.hop}_m{args.m}.wav"
    png_name = f"spec_hop{args.hop}_m{args.m}.png"

    write_wav(wav_name, generate_stego(args.hop, args.m))
    result = evaluate(args.hop, args.m)

    Path(f"generated_hop{args.hop}_m{args.m}.txt").write_text(
        f"GENERATE ONE DONE\nHOP = {args.hop}\nM = {args.m}\n"
        f"WAV = {wav_name}\nPSNR = {result['psnr']:.2f} dB\n"
        f"BER = {result['ber']:.2f}%\nCapacity = {result['capacity']:.2f} bit/s\n",
        encoding="utf-8",
    )

    print(f"Generating stego with hop={args.hop}, m={args.m}...")
    print(f"[+] Created {wav_name}")
    print(f"[+] PSNR = {result['psnr']:.2f} dB")
    print(f"[+] BER = {result['ber']:.2f}%")
    print(f"[+] Capacity = {result['capacity']:.2f} bit/s")

    if args.export_spec:
        save_spectrogram_png(wav_name, png_name)
        print(f"[+] Exported {png_name}")


if __name__ == "__main__":
    main()
