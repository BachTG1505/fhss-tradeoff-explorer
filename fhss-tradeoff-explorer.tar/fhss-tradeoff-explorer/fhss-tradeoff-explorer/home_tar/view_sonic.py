import argparse
import subprocess
from pathlib import Path

FILES = {
    "slow": ("stego_hop1_m2.wav", "viewed_hop1_m2.txt"),
    "fast": ("stego_hop5_m2.wav", "viewed_hop5_m2.txt"),
    "mfsk": ("stego_hop1_m8.wav", "viewed_hop1_m8.txt"),
}

parser = argparse.ArgumentParser()
parser.add_argument("--case", required=True, choices=FILES.keys())
args = parser.parse_args()

wav, marker = FILES[args.case]
subprocess.Popen(["sonic-visualiser", wav])
Path(marker).write_text(f"Viewed {wav} with Sonic Visualiser\n")
print(f"Opened Sonic Visualiser for {wav}")
print(f"Marker written: {marker}")
